// This file will contain part of your solution
#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <ostream>
#include "AbstractList.h"
#include "Node.h"

// Make the ArrayList struct conform to AbstractList

struct LinkedList: public AbstractList{
    Node* head;             // Keep a pointer to the head (first element) of the list

    LinkedList(){       
        head = nullptr;     // A null pointer for head means the list is empty
    }

    void prepend(int value){
        if (head == nullptr){           // If we currently have an empty list
            head = new Node(value);     // Create a new node with the given value and make that the head
        }
        else{                               // If there are already elements in the list
            Node* temp = new Node(value);   // Make a new node with the given value
            temp->next = head;              // Make the current head to be the next element of the newly created node
            head = temp;                    // Point the head to the newly created node
        }
    }

    void append(int value){
        if (head == nullptr){               // If we have an empty list
            head = new Node(value);         // Create a new node with the given value and make that the head
        }
        else{                               // If there are already elements in the list
            Node* temp = new Node(value);   // Make a new node with the given value

            Node* last = head;              // Find the last element in the list
            while (last->next != nullptr){  // That is the first element whose next pointer is null
                last = last->next;
            }

            last->next = temp;              // Make the next pointer of the last element point to the newly created node
        }
    }
    void removeFirst(){
        if(head != NULL){ //if head is not null, then it creates
            Node* temp = head; //a temp node which points to the head
            head = head -> next; //this moves head to the next of the head
            free(temp); //deletes temp node
        }
    }

    void removeLast(){
        if(head!= NULL){ //if head is not null
            if(head->next == NULL){ //if next to head is null
                head = NULL;
            }
            else{ //else, it traverses to the second last element of the list
                Node* temp = head;
                while(temp->next->next != NULL){
                    temp = temp -> next;
                }
                Node* lastNode = temp->next; //this changes the next of the second
                temp->next = NULL; //last node to null and delete the last node
                free(lastNode);
            }
        }

    }
    ~LinkedList(){                  // We must release all the memory we are occupying, which is not necessarily one contiguous chunk
        Node* temp = head;          // Start at the head
        while (head != nullptr){    // As long as there are more elements
            head = head->next;      // release the head element and make its pointer point to the next element
            delete temp;
            temp = head;
        }
    }
};

std::ostream& operator<< (std::ostream& os, LinkedList& list){ // Print out the list on one line, separating elements by a space
    Node* current = list.head;
    while (current != nullptr){
        os << current->data << " ";
        current = current->next;
    }

    return os;
}


#endif