#ifndef HASH_TABLE_H
#define HASH_TABLE_H

#include "ArrayList.h"
#include "LinkedList.h"
#include <stdexcept>

struct HashTable{

    // You can declare more instance variables here
    int K;
    ArrayList<LinkedList<int>> storage; //arraylist of linkedlist of ints
    HashTable(){
        K = 10;
        for (int i = 0; i < K; i++){
            storage.append(LinkedList<int> ()); //appending into an empty linkedlist
        }
        // If you have more instance variables, init them here
    }

    HashTable(int K){
        this->K = K;
        for (int i =0; i < K; i++){
            storage.append(LinkedList<int> ()); //appending into an empty linkedlist
        }
        // If you have more instance variables, init them here
    }

    void add(int value){
        storage.get(abs(value%K)).append(value); 
    }


    bool search(int value){
        return storage.get(abs(value%K)).search(value);
    }

    // You can declare other functions if needed

};

#endif