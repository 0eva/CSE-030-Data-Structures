#include <iostream>
#include <stdexcept>
#include <string>
#include "Queue.h"
#include "Stack.h"

using namespace std;

struct b{
    string name;
    int time;
    b(string x, int y){
        name = x;
        time = y;
    };
    b(){ //initialize empty value in queue for head and tail

    }; 
};
int main(){
    Queue<b> a;
    int jobCount;
    cin >> jobCount;

    for (int i = 0; i < jobCount; i++){
        string name;
        int time;
        cin >> name;
        cin >> time;
        a.enqueue(b(name, time));
        cout << name << " : " << time << endl;
    }

    int period;
    cin >> period;

    // Output round robin schedule, where person can use machine for no longer than the set period
    while(a.length()>0){
        b schedule = a.dequeue();
        if (schedule.time > period){
            schedule.time = schedule.time - period;
            a.enqueue(schedule);
            cout << schedule.name << " - " << period<<endl;
        }
        else{
            cout <<schedule.name<<" - " << schedule.time<<endl;
            
        }
    };

    
    cout << "Done..." << endl;

    return 0;
}