// This file will contain part of your solution
#ifndef ARRAY_LIST_H
#define ARRAY_LIST_H

#include <iostream>
#include <ostream>
#include <stdexcept>
#include <type_traits>
template <class T>
struct ArrayList{
private:
    T* data;
    int capacity;
    int count;

// Helper functions

    bool linear_search(const T& value){
        for (int i = 0; i < count; i++){
            if (data[i] == value){
                return true;
            }
        }
        return false;
    }

    bool binary_search(const T& value){
        int left = 0;
        int right = count;

        while (left <= right){
            int mid = (left + right) / 2;
            if (data[mid] == value){
                return true;
            }
            else if (data[mid] > value){
                right = mid - 1;
            }
            else{
                left = mid + 1;
            }
        }
        return false;
    }

    void swap (int &a, int &b){
        int temp = a;
        a = b;
        b = temp;
    }
    void selection_sort(){
        int min;
        for (int i = 0; i < count-1; i++){
            min = i;
            for (int a = i+1; a < count; a++){
                if(data[a] < data[min]){
                    min = a;
                }
            }
            if (min != i){
                swap(data[min], data[i]);
            }
        }
    }
    void insertion_sort(){
        int a;
        int b;
       for (int i = 1; i<count;i++){
           a = data[i];
           b = i-1;
           while (b >= 0 && data[b] > a){
               data[b+1] = data[b];
               b = b-1;
           }
           data[b +1] = a;
       } 
    }

    T partition(T data[],int &low, int &high){ //to rearrange array
        int piv = data[low];
        int c = 0;
        for (int i = low+1; i<= high; i++){
            if (data[i] <= piv){
                c++;
            }
        }
        //gives pivot element its correct position
        int pivindex = low +c;
        swap(data[pivindex], data[low]);
        //sorts left and right parts of the pivot element
        int i = low;
        int a = high;
        while (i<pivindex && a > pivindex){
            while (data[i] <= piv){
                i++;
            }
            while(data[a] >piv){
                a--;
            }
            if (i < pivindex && a > pivindex){
                swap(data[i++], data[a--]);
            }
        }
        return pivindex;
    }
    void quick_sort(T data[], int low, int high){
        if (low < high){
            int pos = partition(data, low, high);
            quick_sort(data,low, pos-1);
            quick_sort(data,pos +1, high);
        }
    }
                    
public:
    ArrayList(){
        capacity = 1;
        count = 0;
        data = new T[capacity];
    }

    ArrayList(const ArrayList<T>& other){
        count = other.count;
        capacity = other.capacity;

        data = new T[capacity];
        for (int i = 0; i < count; i++){
            data[i] = other.data[i];
        }
    }

    ArrayList<T>& operator=(const ArrayList<T>& other){
        T* oldData = data;
        count = other.count;
        capacity = other.capacity;

        data = new T[capacity];
        for (int i = 0; i < count; i++){
            data[i] = other.data[i];
        }
        delete[] oldData;
    }

    T& operator[](int index){
        return data[index];
    }

    T& get(int index) const{
        return data[index];
    }

    bool operator==(const ArrayList<T>& other) const{
        if (count != other.count){
            return false;
        }

        for (int i = 0; i < count; i++){
            if(data[i] != other.data[i]){
                return false;
            }
        }
        return true;
    }

    void append(T value){
        data[count] = value;
        count++;

        if (count == capacity){

            int oldCapacity = capacity;
            capacity *= 2;

            T* temp = new T[capacity];

            for (int i = 0; i < oldCapacity; i++){
                temp[i] = data[i];
            }

            T* oldLocation = data;
            data = temp;
            delete[] oldLocation;
        }
    }

    int size() const{
        return count;
    }

    bool search(const T& value){
        return binary_search(value);
    }

    void sort(int algo){
        if (algo == 1){
            selection_sort();
        }
        else if(algo == 2){
            insertion_sort();
        }
        else if (algo == 3){
            quick_sort();
        }
    }

    ~ArrayList(){
        delete[] data;
    }
};

template <class T>
std::ostream& operator<<(std::ostream& os, const ArrayList<T>& list){
    for (int i = 0; i < list.size(); i++){
        os << list.get(i) << " ";
    }

    return os;
}

#endif