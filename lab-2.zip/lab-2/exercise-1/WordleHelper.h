#ifndef WORDLE_HELPER_H
#define WORDLE_HELPER_H

#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

class WordleHelper {

  std::vector<std::string> allowed;
  std::vector<std::string> answers;

  std::vector<std::string> green;
  std::vector<std::string> yellow;
  std::vector<std::string> gray;

  bool contains(std::string word, char c) {
    for (int i = 0; i < word.length(); i++) {
      if (word[i] == c) {
        return true;
      }
    }

    return false;
  }

public:
  WordleHelper() {
    std::string answersFile = "answers.txt";
    std::string allowedFile = "allowed.txt";

    std::fstream newfile;

    newfile.open(answersFile, std::ios::in);
    if (newfile.is_open()) {
      std::string tp;

      while (getline(newfile, tp)) {
        answers.push_back(tp);
      }
      newfile.close();
    } else {
      throw std::logic_error("Cant read file " + answersFile + ".");
    }

    newfile.open(allowedFile, std::ios::in);
    if (newfile.is_open()) {
      std::string tp;

      while (getline(newfile, tp)) {
        allowed.push_back(tp);
      }
      newfile.close();
    } else {
      throw std::logic_error("Cant read file " + allowedFile + ".");
    }
  }

  void addGreen(std::string feedback) {
    if (feedback.size() != 5) {
      throw std::logic_error("Green feedback must be exactly 5 characters");
    }
    if (std::any_of(feedback.begin(), feedback.end(),
                    [](char c) { return c != '_' && (c < 'a' || c > 'z'); })) {
      throw std::logic_error(
          "Green feedback must contain only lowercase letters or underscores");
    }

    green.push_back(feedback);
  }

  void addYellow(std::string feedback) {
    if (feedback.size() != 5) {
      throw std::logic_error("Yellow feedback must be exactly 5 characters");
    }
    if (std::any_of(feedback.begin(), feedback.end(),
                    [](char c) { return c != '_' && (c < 'a' || c > 'z'); })) {
      throw std::logic_error(
          "Yellow feedback must contain only lowercase letters or underscores");
    }

    yellow.push_back(feedback);
  }

  void addGray(std::string feedback) {
    if (std::any_of(feedback.begin(), feedback.end(),
                    [](char c) { return c < 'a' && c > 'z'; })) {
      throw std::logic_error(
          "Yellow feedback must contain only lowercase letters");
    }

    gray.push_back(feedback);
  }

  std::vector<std::string> possibleSolutions() {
    std::vector<std::string> possible;
    for (int i = 0; i < answers.size(); i++) { 
      bool pass = true; //Pass tells me if word is possible or not
      for (int b = 0; b < gray.size(); b++) { 
        for (int d = 0; d < gray[b].size(); d++) {
          if (contains(answers[i], gray[b][d])) { //This checks if the gray letter is answers word
            pass = false;
          }
        }
      }
      for (int a = 0; a < 5; a++) {
        for (int c = 0; c < yellow.size(); c++) {
          if (!contains(answers[i], yellow[c][a]) && yellow[c][a] != '_') { //This checks if the word contains yellows
            pass = false;
          }
        }
        if (answers[i][a] != green[green.size() - 1][a] &&
            green[green.size() - 1][a] != '_') { 
          pass = false;
        }
      }
      if (pass) {
        possible.push_back(answers[i]); //if the gray/yellow/green tests pass, then all the possible solutions from answers are added into the vector, possible.
      }
    }
    return possible;
  }

  std::vector<std::string> suggest() {
    // Optionally, your code here...
    return {"bring", "words", "close"};
  }

  ~WordleHelper() {}

  friend struct WordleTester;
};

#endif