#ifndef BSTNODE_H
#define BSTNODE_H
#include <iostream>

template<class T>
struct BSTNode{
    T data;
    BSTNode* parent;
    BSTNode* left;
    BSTNode* right;

    BSTNode(){
        data = 0;
        parent=nullptr;
        left = nullptr;
        right = nullptr;
    }

    BSTNode(T value){
        data = value;
        parent=nullptr;
        left = nullptr;
        right = nullptr;
    }

    BSTNode(T value,BSTNode* p){
        data = value;
        parent = p;
        left = nullptr;
        right = nullptr;
    }
};

template<class T>
struct BST{
private:
    static BSTNode<T>* insert_helper(BSTNode<T>* root,BSTNode<T>* parent,T value){
        if (root == nullptr){
            root = new BSTNode<T>(value, parent);
        }
        else{

            if (value < root->data){
                root->left = insert_helper(root->left, value, root);
            }
            else{
                root->right = insert_helper(root->right, value, root);
            }
        }

        return root;
    }
    static void traverse(BSTNode<T>* root){
        if (root != nullptr){
            traverse(root->left);
            std::cout << root->data << std::endl;
            traverse(root->right);
        }
    }

public:
    BSTNode<T>* root;
    BST(){
        root= nullptr;
    }
    void insert(T value){
        root = insert_helper(root, nullptr, value);
    }
    void traverse(){
        traverse_helper(root);
    }
    void draw(){
        displayTree(root, 0, 1);
    }
    ~BST(){
        delete root;
    }
};


#endif