#ifndef GOODLIST_H
#define GOODLIST_H

#include <ostream>


struct GoodList{
    int* data;
    int count;

    GoodList(){
        count = 0;
        data = new int[10000000];
    }

    void append(int value){
        data[count] = value;
        count++; 
    }

    int& operator[](int index){
        return data[index];
    }

    ~GoodList(){
        delete[] data;
    }
};

std::ostream& operator<<(std::ostream& os, GoodList& gl){

    for(int i = 0; i<gl.count;i++){
        os<<gl.data[i] <<" ";
    }

    return os;
}


#endif